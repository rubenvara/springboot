CREATE TABLE orderTracking (
  orderId         INTEGER ,
  changeStatus INTEGER,
  trackingStatus  DATE 
);

insert into orderTracking VALUES (1,0,sySdate);
insert into orderTracking VALUES (2,2,sySdate);
insert into orderTracking  VALUES(3,0,sySdate);
