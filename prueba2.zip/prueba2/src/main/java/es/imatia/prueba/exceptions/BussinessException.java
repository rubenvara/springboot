package es.imatia.prueba.exceptions;

public class BussinessException extends Exception {

	int code = 0 ;

	public BussinessException(String string, int i) {
		super(string);
		this.code = i;
	}
	
	public int getCode() {
		return code;
	}

}
