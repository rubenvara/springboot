package es.imatia.prueba.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.imatia.prueba.controller.dto.OrderTracking;
import es.imatia.prueba.controller.dto.OrderTrackings;
import es.imatia.prueba.controller.dto.TrackingStatus;
import es.imatia.prueba.exceptions.BussinessException;
import es.imatia.prueba.repo.RepositoryOrderTrackings;
import es.imatia.prueba.stateMachine.StateMachine;

@Service
public class ServiceOrderTrackingsImpl implements ServiceOrderTrackings {

	@Autowired
	RepositoryOrderTrackings repo;

	@Autowired
	StateMachine stateMachine;

	@Override
	public void process(OrderTrackings trackings) throws BussinessException {

		if (trackings.getOrderTrakings() != null) {
			for (OrderTracking orderTracking : trackings.getOrderTrakings()) {
				OrderTracking currentOrderTracking = repo.getCurrentStateOrderTracking(orderTracking.getOrderId());
				checkValidOrder(currentOrderTracking);
				transitAndUpdate(orderTracking, currentOrderTracking);

			}
		}
	}

	private void checkValidOrder(OrderTracking currentOrderTracking) throws BussinessException {
		if (currentOrderTracking == null) {
			throw new BussinessException("No se encuentra la orden", 1);
		}
	}

	private void transitAndUpdate(OrderTracking orderTracking, OrderTracking currentOrderTracking)
			throws BussinessException {
		if (isAvailableTransition(currentOrderTracking.getTrackingStatusId(), orderTracking.getTrackingStatusId())) {
			repo.addStateOrderTracking(orderTracking);
		} else {
			throw new BussinessException("Operacion no válida", 2);
		}
	}

	private boolean isAvailableTransition(TrackingStatus beginState, TrackingStatus endState) {

		return stateMachine.checkTransition(beginState, endState);
	}

}
