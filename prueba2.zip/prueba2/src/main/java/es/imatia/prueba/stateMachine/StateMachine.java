package es.imatia.prueba.stateMachine;

import es.imatia.prueba.controller.dto.TrackingStatus;

public interface StateMachine {

	boolean checkTransition(TrackingStatus beginState, TrackingStatus endState);

}
