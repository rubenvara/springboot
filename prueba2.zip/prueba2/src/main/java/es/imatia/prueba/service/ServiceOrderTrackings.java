package es.imatia.prueba.service;

import es.imatia.prueba.controller.dto.OrderTrackings;
import es.imatia.prueba.exceptions.BussinessException;

public interface ServiceOrderTrackings {

	void process(OrderTrackings trackings) throws BussinessException;

}
