package es.imatia.prueba.repo;

import es.imatia.prueba.controller.dto.OrderTracking;

public interface RepositoryOrderTrackings {

	OrderTracking getCurrentStateOrderTracking(int orderId);

	void addStateOrderTracking(OrderTracking orderTracking);

}
