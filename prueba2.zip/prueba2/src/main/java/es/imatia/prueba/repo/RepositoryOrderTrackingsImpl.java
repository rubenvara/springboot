package es.imatia.prueba.repo;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Service;

import es.imatia.prueba.controller.dto.OrderTracking;
import es.imatia.prueba.repo.mapper.OrderTrackingMapper;

@Service
public class RepositoryOrderTrackingsImpl implements RepositoryOrderTrackings {

	NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Autowired
	public void setNamedParameterJdbcTemplate(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
	}

	@Override
	public OrderTracking getCurrentStateOrderTracking(int orderId) {
		Map params = new HashMap();
		params.put("orderId", orderId);
		List<OrderTracking> rdo = namedParameterJdbcTemplate.query(
				"Select * from orderTracking where orderId = :orderId order by trackingStatus Desc", params,
				new OrderTrackingMapper());
		return rdo.size()>0?rdo.get(0):null;
	}

	@Override
	public void addStateOrderTracking(OrderTracking orderTracking) {
		Map params = new HashMap();
		params.put("orderId", orderTracking.getOrderId());
		params.put("trackingStatusId", orderTracking.getTrackingStatusId().ordinal());
		params.put("changeStatusDate", orderTracking.getChangeStatusDate());
		namedParameterJdbcTemplate
				.update("INSERT INTO orderTracking VALUES (:orderId,:trackingStatusId,:changeStatusDate) ", params);

	}

}
