package es.imatia.prueba.controller.dto;

public enum TrackingStatus {

	RECOGIDO_ALMACEN(1), EN_REPARTO(2), INCIDENCIA_ENTREGA(3), ENTREGADO(4);

	int id;

	TrackingStatus(int id) {
		this.id = id;
	}
}
