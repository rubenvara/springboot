package es.imatia.prueba.util;

import java.io.IOException;
import java.text.SimpleDateFormat;

import org.springframework.boot.jackson.JsonComponent;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

import es.imatia.prueba.controller.dto.OrderTracking;
import es.imatia.prueba.controller.dto.OrderTrackings;

@JsonComponent
public class Serializer {
	public static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";

//	public static class OrderTrackingsDeserializer extends JsonDeserializer<OrderTrackings> {
//
//		@Override
//		public OrderTrackings deserialize(JsonParser p, DeserializationContext ctxt)
//				throws IOException, JsonProcessingException {
//			OrderTrackings ots = new OrderTrackings();
//			
//			return ots;
//		}
//	}

	public static class OrderTrackingsSerializer extends JsonSerializer<OrderTrackings> {

		@Override
		public void serialize(OrderTrackings orderTrackings, JsonGenerator jsonGenerator,
				SerializerProvider serializerProvider) throws IOException, JsonProcessingException {

			SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
			jsonGenerator.writeStartObject();

			jsonGenerator.writeFieldName("orderTrackings");
			jsonGenerator.writeStartArray();
			for (OrderTracking orderTracking : orderTrackings.getOrderTrakings()) {
				jsonGenerator.writeStartObject();
				jsonGenerator.writeFieldName("orderId");
				jsonGenerator.writeNumber(orderTracking.getOrderId());
				jsonGenerator.writeFieldName("trackingStatusId");
				jsonGenerator.writeNumber(orderTracking.getTrackingStatusId().ordinal());
				jsonGenerator.writeFieldName("changeStatusDate");
				jsonGenerator.writeString(sdf.format(orderTracking.getChangeStatusDate().getTime()));
				jsonGenerator.writeEndObject();

			}
			jsonGenerator.writeEndArray();
			jsonGenerator.writeEndObject();
		}

	}
}
