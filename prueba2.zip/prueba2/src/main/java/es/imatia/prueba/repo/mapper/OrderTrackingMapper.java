package es.imatia.prueba.repo.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import es.imatia.prueba.controller.dto.OrderTracking;
import es.imatia.prueba.controller.dto.TrackingStatus;

public class OrderTrackingMapper implements RowMapper<OrderTracking> {

	@Override
	public OrderTracking mapRow(ResultSet rs, int rowNum) throws SQLException {
		OrderTracking rdo = new OrderTracking();
		rdo.setOrderId(rs.getInt(1));

		rdo.setChangeStatusDate(rs.getDate(3));

		rdo.setTrackingStatusId(TrackingStatus.values()[rs.getInt(2)]);
		return rdo;
	}

}
