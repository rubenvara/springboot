package es.imatia.prueba.stateMachine;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Service;

import es.imatia.prueba.controller.dto.TrackingStatus;

@Service
public class StateMachinImpl implements StateMachine {

	private static Map<Transition, Boolean> forbidden = new HashMap<Transition, Boolean>();
	static {
		forbidden.put(new Transition(TrackingStatus.ENTREGADO, TrackingStatus.RECOGIDO_ALMACEN), Boolean.TRUE);
		forbidden.put(new Transition(TrackingStatus.INCIDENCIA_ENTREGA, TrackingStatus.RECOGIDO_ALMACEN), Boolean.TRUE);
		forbidden.put(new Transition(TrackingStatus.EN_REPARTO, TrackingStatus.RECOGIDO_ALMACEN), Boolean.TRUE);

		forbidden.put(new Transition(TrackingStatus.ENTREGADO, TrackingStatus.INCIDENCIA_ENTREGA), Boolean.TRUE);
		forbidden.put(new Transition(TrackingStatus.ENTREGADO, TrackingStatus.EN_REPARTO), Boolean.TRUE);

	}

	@Override
	public boolean checkTransition(TrackingStatus beginState, TrackingStatus endState) {

		return !forbidden.containsKey(new Transition(beginState, endState));
	}

	static class Transition {
		TrackingStatus origen;
		TrackingStatus destino;

		public Transition(TrackingStatus origen, TrackingStatus destino) {
			this.origen = origen;
			this.destino = destino;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Transition other = (Transition) obj;
			if (destino != other.destino)
				return false;
			if (origen != other.origen)
				return false;
			return true;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((destino == null) ? 0 : destino.hashCode());
			result = prime * result + ((origen == null) ? 0 : origen.hashCode());
			return result;
		}
	}
}
