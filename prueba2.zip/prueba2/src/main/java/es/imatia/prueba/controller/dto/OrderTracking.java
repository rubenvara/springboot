package es.imatia.prueba.controller.dto;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import es.imatia.prueba.util.Serializer;

public class OrderTracking implements Serializable {

	int orderId;
	TrackingStatus trackingStatusId;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Serializer.DATE_FORMAT)
	Date changeStatusDate;

	public OrderTracking() {

	}

	public OrderTracking(int orderId, TrackingStatus trackingStatusId, Date changeStatusDate) {
		super();
		this.orderId = orderId;
		this.trackingStatusId = trackingStatusId;
		this.changeStatusDate = changeStatusDate;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public TrackingStatus getTrackingStatusId() {
		return trackingStatusId;
	}

	public void setTrackingStatusId(TrackingStatus trackingStatusId) {
		this.trackingStatusId = trackingStatusId;
	}

	public Date getChangeStatusDate() {
		return changeStatusDate;
	}

	public void setChangeStatusDate(Date changeStatusDate) {
		this.changeStatusDate = changeStatusDate;
	}

}
