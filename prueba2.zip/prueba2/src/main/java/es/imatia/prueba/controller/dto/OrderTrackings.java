package es.imatia.prueba.controller.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class OrderTrackings implements Serializable {

	@JsonProperty("orderTrackings")
	List<OrderTracking> orderTrackings = null;

	public OrderTrackings() {

	}

	public OrderTrackings(List<OrderTracking> orderTrakings) {
		super();
		this.orderTrackings = orderTrakings;
	}

	public List<OrderTracking> getOrderTrakings() {
		return orderTrackings;
	}

	public void setOrderTrakings(List<OrderTracking> orderTrackings) {
		this.orderTrackings = orderTrackings;
	}
}
