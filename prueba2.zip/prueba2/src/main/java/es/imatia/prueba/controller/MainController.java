package es.imatia.prueba.controller;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;

import es.imatia.prueba.controller.dto.OrderTrackings;
import es.imatia.prueba.controller.dto.Resultado;
import es.imatia.prueba.exceptions.BussinessException;
import es.imatia.prueba.service.ServiceOrderTrackings;

@RestController
@RequestMapping("/order")
public class MainController {
	@Autowired
	private ObjectMapper objectMapper;
	private static Logger LOGGER = Logger.getLogger(MainController.class);

	@Autowired
	ServiceOrderTrackings service;

	@PostMapping(value = "/tracking", consumes = MediaType.APPLICATION_JSON_VALUE)
	public Resultado updateOrders(@RequestBody OrderTrackings trackings) {
		Resultado rdo = new Resultado();
		LOGGER.debug("Iniciando proceso " + trackings);
		try {
			service.process(trackings);
		} catch (BussinessException e) {
			rdo.setEstado(e.getCode());
			LOGGER.error(e.getMessage(), e);
		}
		return rdo;
	}
}
