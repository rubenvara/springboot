package es.imatia.prueba;

import static org.junit.Assert.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import es.imatia.prueba.controller.dto.TrackingStatus;
import es.imatia.prueba.stateMachine.StateMachinImpl;
import es.imatia.prueba.stateMachine.StateMachine;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = { StateMachinImpl.class })
public class StateMachineTest {
	@Autowired
	StateMachine stateMachine;

	@Test
	public void checkState() {
		assertTrue(stateMachine.checkTransition(TrackingStatus.EN_REPARTO, TrackingStatus.ENTREGADO));
		assertTrue(stateMachine.checkTransition(TrackingStatus.RECOGIDO_ALMACEN, TrackingStatus.ENTREGADO));
		assertTrue(stateMachine.checkTransition(TrackingStatus.INCIDENCIA_ENTREGA, TrackingStatus.ENTREGADO));
		assertTrue(stateMachine.checkTransition(TrackingStatus.INCIDENCIA_ENTREGA, TrackingStatus.EN_REPARTO));
		assertTrue(stateMachine.checkTransition(TrackingStatus.EN_REPARTO, TrackingStatus.INCIDENCIA_ENTREGA));
			
		assertFalse(stateMachine.checkTransition(TrackingStatus.ENTREGADO, TrackingStatus.EN_REPARTO));
		assertFalse(stateMachine.checkTransition(TrackingStatus.ENTREGADO, TrackingStatus.INCIDENCIA_ENTREGA));
		assertFalse(stateMachine.checkTransition(TrackingStatus.ENTREGADO, TrackingStatus.RECOGIDO_ALMACEN));
		
		assertFalse(stateMachine.checkTransition(TrackingStatus.INCIDENCIA_ENTREGA, TrackingStatus.RECOGIDO_ALMACEN));
		assertFalse(stateMachine.checkTransition(TrackingStatus.EN_REPARTO, TrackingStatus.RECOGIDO_ALMACEN));
		assertFalse(stateMachine.checkTransition(TrackingStatus.ENTREGADO, TrackingStatus.RECOGIDO_ALMACEN));
		
	}
}
