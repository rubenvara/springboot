package es.imatia.prueba;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.util.MimeTypeUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import es.imatia.prueba.controller.MainController;
import es.imatia.prueba.controller.dto.OrderTracking;
import es.imatia.prueba.controller.dto.OrderTrackings;
import es.imatia.prueba.controller.dto.TrackingStatus;

@RunWith(SpringRunner.class)
@WebMvcTest(controllers = MainController.class)
@ContextConfiguration
public class ControllerTest {

	@Configuration
	@ComponentScan("es.imatia")
	public static class SpringConfig {

	}

	@Autowired
	private MockMvc mockMvc;
	@Autowired
	private ObjectMapper objectMapper;

	@Test
	public void firstTest() throws Exception {

		byte[] exampleContent = buildContent();

		final ResultActions result = mockMvc.perform(post("/order/tracking/").content(exampleContent)
				.contentType(MediaType.APPLICATION_JSON_VALUE).accept(MimeTypeUtils.APPLICATION_JSON_VALUE));
		result.andDo(MockMvcResultHandlers.print());
	}

	@Test
	public void secondTest() throws Exception {

		byte[] exampleContent = buildContent1();

		final ResultActions result = mockMvc.perform(post("/order/tracking/").content(exampleContent)
				.contentType(MediaType.APPLICATION_JSON_VALUE).accept(MimeTypeUtils.APPLICATION_JSON_VALUE));
		result.andDo(MockMvcResultHandlers.print());
	}

	@Test
	public void thirdTest() throws Exception {

		byte[] exampleContent = buildContent2();

		final ResultActions result = mockMvc.perform(post("/order/tracking/").content(exampleContent)
				.contentType(MediaType.APPLICATION_JSON_VALUE).accept(MimeTypeUtils.APPLICATION_JSON_VALUE));
		result.andDo(MockMvcResultHandlers.print());
	}

	private byte[] buildContent() throws JsonProcessingException {

		return objectMapper.writeValueAsBytes(getExample());
	}

	private byte[] buildContent1() throws JsonProcessingException {

		return objectMapper.writeValueAsBytes(getExample1());
	}

	private byte[] buildContent2() throws JsonProcessingException {

		return objectMapper.writeValueAsBytes(getExample2());
	}

	private OrderTrackings getExample() {
		OrderTracking order = new OrderTracking(1, TrackingStatus.RECOGIDO_ALMACEN, Calendar.getInstance().getTime());
		List<OrderTracking> lista = new ArrayList(1);
		lista.add(order);
		return new OrderTrackings(lista);
	}

	private OrderTrackings getExample1() {
		OrderTracking order = new OrderTracking(2, TrackingStatus.ENTREGADO, Calendar.getInstance().getTime());
		List<OrderTracking> lista = new ArrayList(1);
		lista.add(order);
		return new OrderTrackings(lista);
	}

	private OrderTrackings getExample2() {
		OrderTracking order = new OrderTracking(4, TrackingStatus.INCIDENCIA_ENTREGA, Calendar.getInstance().getTime());
		List<OrderTracking> lista = new ArrayList(1);
		lista.add(order);
		return new OrderTrackings(lista);
	}
}
